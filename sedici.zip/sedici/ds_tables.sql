-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 04-03-2016 a las 11:21:35
-- Versión del servidor: 5.5.46-0ubuntu0.14.04.2
-- Versión de PHP: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `virtual`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ds_sedici`
--

CREATE TABLE IF NOT EXISTS `ds_sedici` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` tinyint(1) DEFAULT NULL,
  `type` varchar(10) NOT NULL,
  `show_author` tinyint(1) NOT NULL,
  `context` varchar(255) NOT NULL,
  `summary` tinyint(1) NOT NULL,
  `date` tinyint(1) NOT NULL,
  `max_lenght` int(11) NOT NULL,
  `cache` int(11) NOT NULL,
  `all_results` tinyint(1) NOT NULL,
  `limit_text` tinyint(1) NOT NULL,
  `max_results` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Volcado de datos para la tabla `ds_sedici`
--

INSERT INTO `ds_sedici` (`id`, `description`, `type`, `show_author`, `context`, `summary`, `date`, `max_lenght`, `cache`, `all_results`, `limit_text`, `max_results`) VALUES
(1, NULL, '', 0, '', 0, 0, 0, 0, 0, 0, 0),
(2, NULL, '', 0, '', 0, 0, 0, 0, 0, 0, 0),
(3, NULL, '', 0, '', 0, 0, 0, 0, 0, 0, 0),
(4, NULL, '', 0, '', 0, 0, 0, 0, 0, 0, 0),
(5, NULL, '', 0, '', 0, 0, 0, 0, 0, 0, 0),
(6, NULL, '', 0, '', 0, 0, 0, 0, 0, 0, 0),
(7, NULL, '', 0, '', 0, 0, 0, 0, 0, 0, 0),
(8, NULL, '', 0, '', 0, 0, 0, 0, 0, 0, 0),
(9, NULL, '', 0, '', 0, 0, 0, 0, 0, 0, 0),
(10, NULL, '', 0, '', 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ds_subtipos`
--

CREATE TABLE IF NOT EXISTS `ds_subtipos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article` tinyint(1) NOT NULL,
  `book` tinyint(1) NOT NULL,
  `preprint` tinyint(1) NOT NULL,
  `working_paper` tinyint(1) NOT NULL,
  `technical_report` tinyint(1) NOT NULL,
  `conference_object` tinyint(1) NOT NULL,
  `revision` tinyint(1) NOT NULL,
  `work_specialization` tinyint(1) NOT NULL,
  `phd` tinyint(1) NOT NULL,
  `licentiate` tinyint(1) NOT NULL,
  `master` tinyint(1) NOT NULL,
  `id_sedici` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Volcado de datos para la tabla `ds_subtipos`
--

INSERT INTO `ds_subtipos` (`id`, `article`, `book`, `preprint`, `working_paper`, `technical_report`, `conference_object`, `revision`, `work_specialization`, `phd`, `licentiate`, `master`, `id_sedici`) VALUES
(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2),
(3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4),
(5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5),
(6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6),
(7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7),
(8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8),
(9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9),
(10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
