#!/bin/bash
contadorArgumentos=0
argumentosValidos=true
proyectoSeteado=false
help=false
argumento=""

function cargarDesdeArchivo {
dirProyecto="$1"
if [ -d "$dirProyecto" ];
then
	if [[ -d "$dirProyecto"/config && -d "$dirProyecto"/plugins ]];
	then
		databases=`find "$dirProyecto"/config -name "databases.yml"`
		hostspec=`cat $databases | grep hostspec | cut -d":" -f2 | tr -d [[:space:]]`
		database=`cat $databases | grep database | cut -d":" -f2 | tr -d [[:space:]]`
		username=`cat $databases | grep username | cut -d":" -f2 | tr -d [[:space:]]`
		password=`cat $databases | grep password | cut -d":" -f2 | tr -d [[:space:]]`
		mysql -h "$hostspec" -u "$username" -p"$password" -D "$database" -e 'source virtual.sql'
	else
		echo "No se encuentra el directorio config/plugins dentro de $dirProyecto"
		return 1;
	fi
else
	echo "El directorio $dirProyecto no existe"
	return 1;
fi
return 0;	
	}

function validar {
	val=`echo $1 | grep "=" | wc -c`
	if [ "$val" -ne 0 ]; then
		argumento=`echo "$1" | cut -d"=" -f2`
		val=`echo "$argumento" | wc -c`
		if [ "$val" -lt 2 ]; then
			argumentosValidos=false
			return 1;
		else
			let contadorArgumentos=$contadorArgumentos+1
			return 0;
		fi
	fi
	return 1;
}

function imprimirHelp {
	echo "La instalacion puede ser automatica ingresando solo el argumento -p=DirectorioProyecto"
	echo "El script tomara el usuario, pass, host y nombre de la base de datos para realizar las configuraciones necesarias desde el proyecto."
	echo ""
	echo "Ejemplo: ./install.sh -p=/Home/miProyecto"
	echo ""
	echo "------------------------------------------"
	echo ""
	echo "La otra manera de realizar la instalacion es ingresando todos los campos"
	echo '-db="Nombre de la base de datos"'
	echo '-u="Usuario de la base de datos"'
	echo '-s="Host de la base de datos"'
	echo "Ejemplo: ./install.sh -p=/Home/miProyecto  -u=MiUsuario -db=MiBD -s=Localhost "
	echo "Luego se le pedira que ingrese la pass de la base de datos"
	return;
	}

for arg in "$@"
do
    case "$arg" in
    -s*)   validar "$arg"
		   if [ "$?" -eq 0 ]; then
				hostspec="$argumento"
		   fi
            ;;
    -db*)  validar "$arg"
		   if [ "$?" -eq 0 ]; then
				database="$argumento"
		   fi
            ;;
    -u*)   validar "$arg"
		   if [ "$?" -eq 0 ]; then
				username="$argumento"
		   fi
            ;;
    -p*)  	validar "$arg"
			if [ "$?" -ne 1 ]; then
				proyectoSeteado=true
				dirProyecto="$argumento"
			fi
            ;;
    -h)    	imprimirHelp
			help=true
            ;;
    *)    	imprimirHelp
			help=true
            ;;
    esac
done

if [ "$help" = false ]; then
	consultaEjecutada=false
	if [[ "$proyectoSeteado" = true && "$argumentosValidos" = true ]]; then
		if [ "$contadorArgumentos" -eq 1 ]; then
			cargarDesdeArchivo "$dirProyecto"
			if [ "$?" -eq 0 ]; then
				consultaEjecutada=true
			fi
		else
			if [ "$contadorArgumentos" -eq 4 ]; then
				mysql -h "$hostspec" -u "$username" -p -D "$database" -e 'source ds_tables.sql'
				if [ "$?" -eq 0 ]; then
					consultaEjecutada=true
				fi
			else
				echo "Faltan argumentos"
				imprimirHelp
			fi
		fi
		if [ "$consultaEjecutada" = true ]; then
			cp -r sfDspacePlugin "$dirProyecto"/plugins
			ln -sf "$dirProyecto"/plugins/sfDspacePlugin/web-backend/css/ds-css.css "$dirProyecto"/web-backend/css/backend
			ln -sf "$dirProyecto"/plugins/sfDspacePlugin/web-backend/js/ds-menu.js "$dirProyecto"/web-backend/js
			echo "Para que funcionen los cambios es necesario correr el comando propel-build-model y limpiar la cache"
			echo "Desea ejecutarlos ahora? Ingrese S/N"
			read respuesta
			if [[ "$respuesta" = "S" || "$respuesta" = "s" ]]; then
				cd "$dirProyecto"
				php symfony propel-build-model
				php symfony cc
			fi
		else
			echo "Error al importar las tablas a la base de datos. Puede que el usuario no tenga los permisos necesarios o argumentos enviados no sean correctos."
		fi
	else
		echo "Error en el envio de los argumentos"
		imprimirHelp
	fi
fi
