<?php



class sediciMapBuilder {

	
	const CLASS_NAME = 'plugins.sfDspacePlugin.lib.model.map.sediciMapBuilder';

	
	private $dbMap;

	
	public function isBuilt()
	{
		return ($this->dbMap !== null);
	}

	
	public function getDatabaseMap()
	{
		return $this->dbMap;
	}

	
	public function doBuild()
	{
		$this->dbMap = Propel::getDatabaseMap('propel');

		$tMap = $this->dbMap->addTable('ds_sedici');
		$tMap->setPhpName('sedici');

		$tMap->setUseIdGenerator(true);

		$tMap->addPrimaryKey('ID', 'Id', 'int', CreoleTypes::INTEGER, true, null);

		$tMap->addColumn('TYPE', 'Type', 'string', CreoleTypes::VARCHAR, true, 10);

		$tMap->addColumn('CONTEXT', 'Context', 'string', CreoleTypes::VARCHAR, true, 255);

		$tMap->addColumn('DESCRIPTION', 'Description', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('SUMMARY', 'Summary', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('SHOW_AUTHOR', 'ShowAuthor', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('MAX_LENGHT', 'MaxLenght', 'int', CreoleTypes::INTEGER, false, null);

		$tMap->addColumn('CACHE', 'Cache', 'int', CreoleTypes::INTEGER, false, null);

		$tMap->addColumn('MAX_RESULTS', 'MaxResults', 'int', CreoleTypes::INTEGER, false, null);

		$tMap->addColumn('DATE', 'Date', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('LIMIT_TEXT', 'LimitText', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('ALL_RESULTS', 'AllResults', 'boolean', CreoleTypes::BOOLEAN, false, null);

	} 
} 