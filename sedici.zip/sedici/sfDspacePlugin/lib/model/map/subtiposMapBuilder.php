<?php



class subtiposMapBuilder {

	
	const CLASS_NAME = 'plugins.sfDspacePlugin.lib.model.map.subtiposMapBuilder';

	
	private $dbMap;

	
	public function isBuilt()
	{
		return ($this->dbMap !== null);
	}

	
	public function getDatabaseMap()
	{
		return $this->dbMap;
	}

	
	public function doBuild()
	{
		$this->dbMap = Propel::getDatabaseMap('propel');

		$tMap = $this->dbMap->addTable('ds_subtipos');
		$tMap->setPhpName('subtipos');

		$tMap->setUseIdGenerator(true);

		$tMap->addPrimaryKey('ID', 'Id', 'int', CreoleTypes::INTEGER, true, null);

		$tMap->addColumn('ARTICLE', 'Article', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('BOOK', 'Book', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('PREPRINT', 'Preprint', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('WORKING_PAPER', 'WorkingPaper', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('TECHNICAL_REPORT', 'TechnicalReport', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('CONFERENCE_OBJECT', 'ConferenceObject', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('REVISION', 'Revision', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('WORK_SPECIALIZATION', 'WorkSpecialization', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('PHD', 'Phd', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('LICENTIATE', 'Licentiate', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('MASTER', 'Master', 'boolean', CreoleTypes::BOOLEAN, false, null);

		$tMap->addColumn('ID_SEDICI', 'IdSedici', 'int', CreoleTypes::INTEGER, false, null);

	} 
} 