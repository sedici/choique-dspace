<?php


abstract class Basesedici extends BaseObject  implements Persistent {


	
	protected static $peer;


	
	protected $id;


	
	protected $type;


	
	protected $context;


	
	protected $description;


	
	protected $summary;


	
	protected $show_author;


	
	protected $max_lenght;


	
	protected $cache;


	
	protected $max_results;


	
	protected $date;


	
	protected $limit_text;


	
	protected $all_results;

	
	protected $alreadyInSave = false;

	
	protected $alreadyInValidation = false;

	
	public function getId()
	{

		return $this->id;
	}

	
	public function getType()
	{

		return $this->type;
	}

	
	public function getContext()
	{

		return $this->context;
	}

	
	public function getDescription()
	{

		return $this->description;
	}

	
	public function getSummary()
	{

		return $this->summary;
	}

	
	public function getShowAuthor()
	{

		return $this->show_author;
	}

	
	public function getMaxLenght()
	{

		return $this->max_lenght;
	}

	
	public function getCache()
	{

		return $this->cache;
	}

	
	public function getMaxResults()
	{

		return $this->max_results;
	}

	
	public function getDate()
	{

		return $this->date;
	}

	
	public function getLimitText()
	{

		return $this->limit_text;
	}

	
	public function getAllResults()
	{

		return $this->all_results;
	}

	
	public function setId($v)
	{

						if ($v !== null && !is_int($v) && is_numeric($v)) {
			$v = (int) $v;
		}

		if ($this->id !== $v) {
			$this->id = $v;
			$this->modifiedColumns[] = sediciPeer::ID;
		}

	} 
	
	public function setType($v)
	{

						if ($v !== null && !is_string($v)) {
			$v = (string) $v; 
		}

		if ($this->type !== $v) {
			$this->type = $v;
			$this->modifiedColumns[] = sediciPeer::TYPE;
		}

	} 
	
	public function setContext($v)
	{

						if ($v !== null && !is_string($v)) {
			$v = (string) $v; 
		}

		if ($this->context !== $v) {
			$this->context = $v;
			$this->modifiedColumns[] = sediciPeer::CONTEXT;
		}

	} 
	
	public function setDescription($v)
	{

		if ($this->description !== $v) {
			$this->description = $v;
			$this->modifiedColumns[] = sediciPeer::DESCRIPTION;
		}

	} 
	
	public function setSummary($v)
	{

		if ($this->summary !== $v) {
			$this->summary = $v;
			$this->modifiedColumns[] = sediciPeer::SUMMARY;
		}

	} 
	
	public function setShowAuthor($v)
	{

		if ($this->show_author !== $v) {
			$this->show_author = $v;
			$this->modifiedColumns[] = sediciPeer::SHOW_AUTHOR;
		}

	} 
	
	public function setMaxLenght($v)
	{

						if ($v !== null && !is_int($v) && is_numeric($v)) {
			$v = (int) $v;
		}

		if ($this->max_lenght !== $v) {
			$this->max_lenght = $v;
			$this->modifiedColumns[] = sediciPeer::MAX_LENGHT;
		}

	} 
	
	public function setCache($v)
	{

						if ($v !== null && !is_int($v) && is_numeric($v)) {
			$v = (int) $v;
		}

		if ($this->cache !== $v) {
			$this->cache = $v;
			$this->modifiedColumns[] = sediciPeer::CACHE;
		}

	} 
	
	public function setMaxResults($v)
	{

						if ($v !== null && !is_int($v) && is_numeric($v)) {
			$v = (int) $v;
		}

		if ($this->max_results !== $v) {
			$this->max_results = $v;
			$this->modifiedColumns[] = sediciPeer::MAX_RESULTS;
		}

	} 
	
	public function setDate($v)
	{

		if ($this->date !== $v) {
			$this->date = $v;
			$this->modifiedColumns[] = sediciPeer::DATE;
		}

	} 
	
	public function setLimitText($v)
	{

		if ($this->limit_text !== $v) {
			$this->limit_text = $v;
			$this->modifiedColumns[] = sediciPeer::LIMIT_TEXT;
		}

	} 
	
	public function setAllResults($v)
	{

		if ($this->all_results !== $v) {
			$this->all_results = $v;
			$this->modifiedColumns[] = sediciPeer::ALL_RESULTS;
		}

	} 
	
	public function hydrate(ResultSet $rs, $startcol = 1)
	{
		try {

			$this->id = $rs->getInt($startcol + 0);

			$this->type = $rs->getString($startcol + 1);

			$this->context = $rs->getString($startcol + 2);

			$this->description = $rs->getBoolean($startcol + 3);

			$this->summary = $rs->getBoolean($startcol + 4);

			$this->show_author = $rs->getBoolean($startcol + 5);

			$this->max_lenght = $rs->getInt($startcol + 6);

			$this->cache = $rs->getInt($startcol + 7);

			$this->max_results = $rs->getInt($startcol + 8);

			$this->date = $rs->getBoolean($startcol + 9);

			$this->limit_text = $rs->getBoolean($startcol + 10);

			$this->all_results = $rs->getBoolean($startcol + 11);

			$this->resetModified();

			$this->setNew(false);

						return $startcol + 12; 
		} catch (Exception $e) {
			throw new PropelException("Error populating sedici object", $e);
		}
	}

	
	public function delete($con = null)
	{

    foreach (sfMixer::getCallables('Basesedici:delete:pre') as $callable)
    {
      $ret = call_user_func($callable, $this, $con);
      if ($ret)
      {
        return;
      }
    }


		if ($this->isDeleted()) {
			throw new PropelException("This object has already been deleted.");
		}

		if ($con === null) {
			$con = Propel::getConnection(sediciPeer::DATABASE_NAME);
		}

		try {
			$con->begin();
			sediciPeer::doDelete($this, $con);
			$this->setDeleted(true);
			$con->commit();
		} catch (PropelException $e) {
			$con->rollback();
			throw $e;
		}
	

    foreach (sfMixer::getCallables('Basesedici:delete:post') as $callable)
    {
      call_user_func($callable, $this, $con);
    }

  }
	
	public function save($con = null)
	{

    foreach (sfMixer::getCallables('Basesedici:save:pre') as $callable)
    {
      $affectedRows = call_user_func($callable, $this, $con);
      if (is_int($affectedRows))
      {
        return $affectedRows;
      }
    }


		if ($this->isDeleted()) {
			throw new PropelException("You cannot save an object that has been deleted.");
		}

		if ($con === null) {
			$con = Propel::getConnection(sediciPeer::DATABASE_NAME);
		}

		try {
			$con->begin();
			$affectedRows = $this->doSave($con);
			$con->commit();
    foreach (sfMixer::getCallables('Basesedici:save:post') as $callable)
    {
      call_user_func($callable, $this, $con, $affectedRows);
    }

			return $affectedRows;
		} catch (PropelException $e) {
			$con->rollback();
			throw $e;
		}
	}

	
	protected function doSave($con)
	{
		$affectedRows = 0; 		if (!$this->alreadyInSave) {
			$this->alreadyInSave = true;


						if ($this->isModified()) {
				if ($this->isNew()) {
					$pk = sediciPeer::doInsert($this, $con);
					$affectedRows += 1; 										 										 
					$this->setId($pk);  
					$this->setNew(false);
				} else {
					$affectedRows += sediciPeer::doUpdate($this, $con);
				}
				$this->resetModified(); 			}

			$this->alreadyInSave = false;
		}
		return $affectedRows;
	} 
	
	protected $validationFailures = array();

	
	public function getValidationFailures()
	{
		return $this->validationFailures;
	}

	
	public function validate($columns = null)
	{
		$res = $this->doValidate($columns);
		if ($res === true) {
			$this->validationFailures = array();
			return true;
		} else {
			$this->validationFailures = $res;
			return false;
		}
	}

	
	protected function doValidate($columns = null)
	{
		if (!$this->alreadyInValidation) {
			$this->alreadyInValidation = true;
			$retval = null;

			$failureMap = array();


			if (($retval = sediciPeer::doValidate($this, $columns)) !== true) {
				$failureMap = array_merge($failureMap, $retval);
			}



			$this->alreadyInValidation = false;
		}

		return (!empty($failureMap) ? $failureMap : true);
	}

	
	public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
	{
		$pos = sediciPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
		return $this->getByPosition($pos);
	}

	
	public function getByPosition($pos)
	{
		switch($pos) {
			case 0:
				return $this->getId();
				break;
			case 1:
				return $this->getType();
				break;
			case 2:
				return $this->getContext();
				break;
			case 3:
				return $this->getDescription();
				break;
			case 4:
				return $this->getSummary();
				break;
			case 5:
				return $this->getShowAuthor();
				break;
			case 6:
				return $this->getMaxLenght();
				break;
			case 7:
				return $this->getCache();
				break;
			case 8:
				return $this->getMaxResults();
				break;
			case 9:
				return $this->getDate();
				break;
			case 10:
				return $this->getLimitText();
				break;
			case 11:
				return $this->getAllResults();
				break;
			default:
				return null;
				break;
		} 	}

	
	public function toArray($keyType = BasePeer::TYPE_PHPNAME)
	{
		$keys = sediciPeer::getFieldNames($keyType);
		$result = array(
			$keys[0] => $this->getId(),
			$keys[1] => $this->getType(),
			$keys[2] => $this->getContext(),
			$keys[3] => $this->getDescription(),
			$keys[4] => $this->getSummary(),
			$keys[5] => $this->getShowAuthor(),
			$keys[6] => $this->getMaxLenght(),
			$keys[7] => $this->getCache(),
			$keys[8] => $this->getMaxResults(),
			$keys[9] => $this->getDate(),
			$keys[10] => $this->getLimitText(),
			$keys[11] => $this->getAllResults(),
		);
		return $result;
	}

	
	public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
	{
		$pos = sediciPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
		return $this->setByPosition($pos, $value);
	}

	
	public function setByPosition($pos, $value)
	{
		switch($pos) {
			case 0:
				$this->setId($value);
				break;
			case 1:
				$this->setType($value);
				break;
			case 2:
				$this->setContext($value);
				break;
			case 3:
				$this->setDescription($value);
				break;
			case 4:
				$this->setSummary($value);
				break;
			case 5:
				$this->setShowAuthor($value);
				break;
			case 6:
				$this->setMaxLenght($value);
				break;
			case 7:
				$this->setCache($value);
				break;
			case 8:
				$this->setMaxResults($value);
				break;
			case 9:
				$this->setDate($value);
				break;
			case 10:
				$this->setLimitText($value);
				break;
			case 11:
				$this->setAllResults($value);
				break;
		} 	}

	
	public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
	{
		$keys = sediciPeer::getFieldNames($keyType);

		if (array_key_exists($keys[0], $arr)) $this->setId($arr[$keys[0]]);
		if (array_key_exists($keys[1], $arr)) $this->setType($arr[$keys[1]]);
		if (array_key_exists($keys[2], $arr)) $this->setContext($arr[$keys[2]]);
		if (array_key_exists($keys[3], $arr)) $this->setDescription($arr[$keys[3]]);
		if (array_key_exists($keys[4], $arr)) $this->setSummary($arr[$keys[4]]);
		if (array_key_exists($keys[5], $arr)) $this->setShowAuthor($arr[$keys[5]]);
		if (array_key_exists($keys[6], $arr)) $this->setMaxLenght($arr[$keys[6]]);
		if (array_key_exists($keys[7], $arr)) $this->setCache($arr[$keys[7]]);
		if (array_key_exists($keys[8], $arr)) $this->setMaxResults($arr[$keys[8]]);
		if (array_key_exists($keys[9], $arr)) $this->setDate($arr[$keys[9]]);
		if (array_key_exists($keys[10], $arr)) $this->setLimitText($arr[$keys[10]]);
		if (array_key_exists($keys[11], $arr)) $this->setAllResults($arr[$keys[11]]);
	}

	
	public function buildCriteria()
	{
		$criteria = new Criteria(sediciPeer::DATABASE_NAME);

		if ($this->isColumnModified(sediciPeer::ID)) $criteria->add(sediciPeer::ID, $this->id);
		if ($this->isColumnModified(sediciPeer::TYPE)) $criteria->add(sediciPeer::TYPE, $this->type);
		if ($this->isColumnModified(sediciPeer::CONTEXT)) $criteria->add(sediciPeer::CONTEXT, $this->context);
		if ($this->isColumnModified(sediciPeer::DESCRIPTION)) $criteria->add(sediciPeer::DESCRIPTION, $this->description);
		if ($this->isColumnModified(sediciPeer::SUMMARY)) $criteria->add(sediciPeer::SUMMARY, $this->summary);
		if ($this->isColumnModified(sediciPeer::SHOW_AUTHOR)) $criteria->add(sediciPeer::SHOW_AUTHOR, $this->show_author);
		if ($this->isColumnModified(sediciPeer::MAX_LENGHT)) $criteria->add(sediciPeer::MAX_LENGHT, $this->max_lenght);
		if ($this->isColumnModified(sediciPeer::CACHE)) $criteria->add(sediciPeer::CACHE, $this->cache);
		if ($this->isColumnModified(sediciPeer::MAX_RESULTS)) $criteria->add(sediciPeer::MAX_RESULTS, $this->max_results);
		if ($this->isColumnModified(sediciPeer::DATE)) $criteria->add(sediciPeer::DATE, $this->date);
		if ($this->isColumnModified(sediciPeer::LIMIT_TEXT)) $criteria->add(sediciPeer::LIMIT_TEXT, $this->limit_text);
		if ($this->isColumnModified(sediciPeer::ALL_RESULTS)) $criteria->add(sediciPeer::ALL_RESULTS, $this->all_results);

		return $criteria;
	}

	
	public function buildPkeyCriteria()
	{
		$criteria = new Criteria(sediciPeer::DATABASE_NAME);

		$criteria->add(sediciPeer::ID, $this->id);

		return $criteria;
	}

	
	public function getPrimaryKey()
	{
		return $this->getId();
	}

	
	public function setPrimaryKey($key)
	{
		$this->setId($key);
	}

	
	public function copyInto($copyObj, $deepCopy = false)
	{

		$copyObj->setType($this->type);

		$copyObj->setContext($this->context);

		$copyObj->setDescription($this->description);

		$copyObj->setSummary($this->summary);

		$copyObj->setShowAuthor($this->show_author);

		$copyObj->setMaxLenght($this->max_lenght);

		$copyObj->setCache($this->cache);

		$copyObj->setMaxResults($this->max_results);

		$copyObj->setDate($this->date);

		$copyObj->setLimitText($this->limit_text);

		$copyObj->setAllResults($this->all_results);


		$copyObj->setNew(true);

		$copyObj->setId(NULL); 
	}

	
	public function copy($deepCopy = false)
	{
				$clazz = get_class($this);
		$copyObj = new $clazz();
		$this->copyInto($copyObj, $deepCopy);
		return $copyObj;
	}

	
	public function getPeer()
	{
		if (self::$peer === null) {
			self::$peer = new sediciPeer();
		}
		return self::$peer;
	}


  public function __call($method, $arguments)
  {
    if (!$callable = sfMixer::getCallable('Basesedici:'.$method))
    {
      throw new sfException(sprintf('Call to undefined method Basesedici::%s', $method));
    }

    array_unshift($arguments, $this);

    return call_user_func_array($callable, $arguments);
  }


} 