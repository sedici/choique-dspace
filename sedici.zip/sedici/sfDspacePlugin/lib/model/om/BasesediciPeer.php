<?php


abstract class BasesediciPeer {

	
	const DATABASE_NAME = 'propel';

	
	const TABLE_NAME = 'ds_sedici';

	
	const CLASS_DEFAULT = 'plugins.sfDspacePlugin.lib.model.sedici';

	
	const NUM_COLUMNS = 12;

	
	const NUM_LAZY_LOAD_COLUMNS = 0;


	
	const ID = 'ds_sedici.ID';

	
	const TYPE = 'ds_sedici.TYPE';

	
	const CONTEXT = 'ds_sedici.CONTEXT';

	
	const DESCRIPTION = 'ds_sedici.DESCRIPTION';

	
	const SUMMARY = 'ds_sedici.SUMMARY';

	
	const SHOW_AUTHOR = 'ds_sedici.SHOW_AUTHOR';

	
	const MAX_LENGHT = 'ds_sedici.MAX_LENGHT';

	
	const CACHE = 'ds_sedici.CACHE';

	
	const MAX_RESULTS = 'ds_sedici.MAX_RESULTS';

	
	const DATE = 'ds_sedici.DATE';

	
	const LIMIT_TEXT = 'ds_sedici.LIMIT_TEXT';

	
	const ALL_RESULTS = 'ds_sedici.ALL_RESULTS';

	
	private static $phpNameMap = null;


	
	private static $fieldNames = array (
		BasePeer::TYPE_PHPNAME => array ('Id', 'Type', 'Context', 'Description', 'Summary', 'ShowAuthor', 'MaxLenght', 'Cache', 'MaxResults', 'Date', 'LimitText', 'AllResults', ),
		BasePeer::TYPE_COLNAME => array (sediciPeer::ID, sediciPeer::TYPE, sediciPeer::CONTEXT, sediciPeer::DESCRIPTION, sediciPeer::SUMMARY, sediciPeer::SHOW_AUTHOR, sediciPeer::MAX_LENGHT, sediciPeer::CACHE, sediciPeer::MAX_RESULTS, sediciPeer::DATE, sediciPeer::LIMIT_TEXT, sediciPeer::ALL_RESULTS, ),
		BasePeer::TYPE_FIELDNAME => array ('id', 'type', 'context', 'description', 'summary', 'show_author', 'max_lenght', 'cache', 'max_results', 'date', 'limit_text', 'all_results', ),
		BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, )
	);

	
	private static $fieldKeys = array (
		BasePeer::TYPE_PHPNAME => array ('Id' => 0, 'Type' => 1, 'Context' => 2, 'Description' => 3, 'Summary' => 4, 'ShowAuthor' => 5, 'MaxLenght' => 6, 'Cache' => 7, 'MaxResults' => 8, 'Date' => 9, 'LimitText' => 10, 'AllResults' => 11, ),
		BasePeer::TYPE_COLNAME => array (sediciPeer::ID => 0, sediciPeer::TYPE => 1, sediciPeer::CONTEXT => 2, sediciPeer::DESCRIPTION => 3, sediciPeer::SUMMARY => 4, sediciPeer::SHOW_AUTHOR => 5, sediciPeer::MAX_LENGHT => 6, sediciPeer::CACHE => 7, sediciPeer::MAX_RESULTS => 8, sediciPeer::DATE => 9, sediciPeer::LIMIT_TEXT => 10, sediciPeer::ALL_RESULTS => 11, ),
		BasePeer::TYPE_FIELDNAME => array ('id' => 0, 'type' => 1, 'context' => 2, 'description' => 3, 'summary' => 4, 'show_author' => 5, 'max_lenght' => 6, 'cache' => 7, 'max_results' => 8, 'date' => 9, 'limit_text' => 10, 'all_results' => 11, ),
		BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, )
	);

	
	public static function getMapBuilder()
	{
		include_once 'plugins/sfDspacePlugin/lib/model/map/sediciMapBuilder.php';
		return BasePeer::getMapBuilder('plugins.sfDspacePlugin.lib.model.map.sediciMapBuilder');
	}
	
	public static function getPhpNameMap()
	{
		if (self::$phpNameMap === null) {
			$map = sediciPeer::getTableMap();
			$columns = $map->getColumns();
			$nameMap = array();
			foreach ($columns as $column) {
				$nameMap[$column->getPhpName()] = $column->getColumnName();
			}
			self::$phpNameMap = $nameMap;
		}
		return self::$phpNameMap;
	}
	
	static public function translateFieldName($name, $fromType, $toType)
	{
		$toNames = self::getFieldNames($toType);
		$key = isset(self::$fieldKeys[$fromType][$name]) ? self::$fieldKeys[$fromType][$name] : null;
		if ($key === null) {
			throw new PropelException("'$name' could not be found in the field names of type '$fromType'. These are: " . print_r(self::$fieldKeys[$fromType], true));
		}
		return $toNames[$key];
	}

	

	static public function getFieldNames($type = BasePeer::TYPE_PHPNAME)
	{
		if (!array_key_exists($type, self::$fieldNames)) {
			throw new PropelException('Method getFieldNames() expects the parameter $type to be one of the class constants TYPE_PHPNAME, TYPE_COLNAME, TYPE_FIELDNAME, TYPE_NUM. ' . $type . ' was given.');
		}
		return self::$fieldNames[$type];
	}

	
	public static function alias($alias, $column)
	{
		return str_replace(sediciPeer::TABLE_NAME.'.', $alias.'.', $column);
	}

	
	public static function addSelectColumns(Criteria $criteria)
	{

		$criteria->addSelectColumn(sediciPeer::ID);

		$criteria->addSelectColumn(sediciPeer::TYPE);

		$criteria->addSelectColumn(sediciPeer::CONTEXT);

		$criteria->addSelectColumn(sediciPeer::DESCRIPTION);

		$criteria->addSelectColumn(sediciPeer::SUMMARY);

		$criteria->addSelectColumn(sediciPeer::SHOW_AUTHOR);

		$criteria->addSelectColumn(sediciPeer::MAX_LENGHT);

		$criteria->addSelectColumn(sediciPeer::CACHE);

		$criteria->addSelectColumn(sediciPeer::MAX_RESULTS);

		$criteria->addSelectColumn(sediciPeer::DATE);

		$criteria->addSelectColumn(sediciPeer::LIMIT_TEXT);

		$criteria->addSelectColumn(sediciPeer::ALL_RESULTS);

	}

	const COUNT = 'COUNT(ds_sedici.ID)';
	const COUNT_DISTINCT = 'COUNT(DISTINCT ds_sedici.ID)';

	
	public static function doCount(Criteria $criteria, $distinct = false, $con = null)
	{
				$criteria = clone $criteria;

				$criteria->clearSelectColumns()->clearOrderByColumns();
		if ($distinct || in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
			$criteria->addSelectColumn(sediciPeer::COUNT_DISTINCT);
		} else {
			$criteria->addSelectColumn(sediciPeer::COUNT);
		}

				foreach($criteria->getGroupByColumns() as $column)
		{
			$criteria->addSelectColumn($column);
		}

		$rs = sediciPeer::doSelectRS($criteria, $con);
		if ($rs->next()) {
			return $rs->getInt(1);
		} else {
						return 0;
		}
	}
	
	public static function doSelectOne(Criteria $criteria, $con = null)
	{
		$critcopy = clone $criteria;
		$critcopy->setLimit(1);
		$objects = sediciPeer::doSelect($critcopy, $con);
		if ($objects) {
			return $objects[0];
		}
		return null;
	}
	
	public static function doSelect(Criteria $criteria, $con = null)
	{
		return sediciPeer::populateObjects(sediciPeer::doSelectRS($criteria, $con));
	}
	
	public static function doSelectRS(Criteria $criteria, $con = null)
	{

    foreach (sfMixer::getCallables('BasesediciPeer:addDoSelectRS:addDoSelectRS') as $callable)
    {
      call_user_func($callable, 'BasesediciPeer', $criteria, $con);
    }


		if ($con === null) {
			$con = Propel::getConnection(self::DATABASE_NAME);
		}

		if (!$criteria->getSelectColumns()) {
			$criteria = clone $criteria;
			sediciPeer::addSelectColumns($criteria);
		}

				$criteria->setDbName(self::DATABASE_NAME);

						return BasePeer::doSelect($criteria, $con);
	}
	
	public static function populateObjects(ResultSet $rs)
	{
		$results = array();
	
				$cls = sediciPeer::getOMClass();
		$cls = Propel::import($cls);
				while($rs->next()) {
		
			$obj = new $cls();
			$obj->hydrate($rs);
			$results[] = $obj;
			
		}
		return $results;
	}
	
	public static function getTableMap()
	{
		return Propel::getDatabaseMap(self::DATABASE_NAME)->getTable(self::TABLE_NAME);
	}

	
	public static function getOMClass()
	{
		return sediciPeer::CLASS_DEFAULT;
	}

	
	public static function doInsert($values, $con = null)
	{

    foreach (sfMixer::getCallables('BasesediciPeer:doInsert:pre') as $callable)
    {
      $ret = call_user_func($callable, 'BasesediciPeer', $values, $con);
      if (false !== $ret)
      {
        return $ret;
      }
    }


		if ($con === null) {
			$con = Propel::getConnection(self::DATABASE_NAME);
		}

		if ($values instanceof Criteria) {
			$criteria = clone $values; 		} else {
			$criteria = $values->buildCriteria(); 		}

		$criteria->remove(sediciPeer::ID); 

				$criteria->setDbName(self::DATABASE_NAME);

		try {
									$con->begin();
			$pk = BasePeer::doInsert($criteria, $con);
			$con->commit();
		} catch(PropelException $e) {
			$con->rollback();
			throw $e;
		}

		
    foreach (sfMixer::getCallables('BasesediciPeer:doInsert:post') as $callable)
    {
      call_user_func($callable, 'BasesediciPeer', $values, $con, $pk);
    }

    return $pk;
	}

	
	public static function doUpdate($values, $con = null)
	{

    foreach (sfMixer::getCallables('BasesediciPeer:doUpdate:pre') as $callable)
    {
      $ret = call_user_func($callable, 'BasesediciPeer', $values, $con);
      if (false !== $ret)
      {
        return $ret;
      }
    }


		if ($con === null) {
			$con = Propel::getConnection(self::DATABASE_NAME);
		}

		$selectCriteria = new Criteria(self::DATABASE_NAME);

		if ($values instanceof Criteria) {
			$criteria = clone $values; 
			$comparison = $criteria->getComparison(sediciPeer::ID);
			$selectCriteria->add(sediciPeer::ID, $criteria->remove(sediciPeer::ID), $comparison);

		} else { 			$criteria = $values->buildCriteria(); 			$selectCriteria = $values->buildPkeyCriteria(); 		}

				$criteria->setDbName(self::DATABASE_NAME);

		$ret = BasePeer::doUpdate($selectCriteria, $criteria, $con);
	

    foreach (sfMixer::getCallables('BasesediciPeer:doUpdate:post') as $callable)
    {
      call_user_func($callable, 'BasesediciPeer', $values, $con, $ret);
    }

    return $ret;
  }

	
	public static function doDeleteAll($con = null)
	{
		if ($con === null) {
			$con = Propel::getConnection(self::DATABASE_NAME);
		}
		$affectedRows = 0; 		try {
									$con->begin();
			$affectedRows += BasePeer::doDeleteAll(sediciPeer::TABLE_NAME, $con);
			$con->commit();
			return $affectedRows;
		} catch (PropelException $e) {
			$con->rollback();
			throw $e;
		}
	}

	
	 public static function doDelete($values, $con = null)
	 {
		if ($con === null) {
			$con = Propel::getConnection(sediciPeer::DATABASE_NAME);
		}

		if ($values instanceof Criteria) {
			$criteria = clone $values; 		} elseif ($values instanceof sedici) {

			$criteria = $values->buildPkeyCriteria();
		} else {
						$criteria = new Criteria(self::DATABASE_NAME);
			$criteria->add(sediciPeer::ID, (array) $values, Criteria::IN);
		}

				$criteria->setDbName(self::DATABASE_NAME);

		$affectedRows = 0; 
		try {
									$con->begin();
			
			$affectedRows += BasePeer::doDelete($criteria, $con);
			$con->commit();
			return $affectedRows;
		} catch (PropelException $e) {
			$con->rollback();
			throw $e;
		}
	}

	
	public static function doValidate(sedici $obj, $cols = null)
	{
		$columns = array();

		if ($cols) {
			$dbMap = Propel::getDatabaseMap(sediciPeer::DATABASE_NAME);
			$tableMap = $dbMap->getTable(sediciPeer::TABLE_NAME);

			if (! is_array($cols)) {
				$cols = array($cols);
			}

			foreach($cols as $colName) {
				if ($tableMap->containsColumn($colName)) {
					$get = 'get' . $tableMap->getColumn($colName)->getPhpName();
					$columns[$colName] = $obj->$get();
				}
			}
		} else {

		}

		$res =  BasePeer::doValidate(sediciPeer::DATABASE_NAME, sediciPeer::TABLE_NAME, $columns);
    if ($res !== true) {
        $request = sfContext::getInstance()->getRequest();
        foreach ($res as $failed) {
            $col = sediciPeer::translateFieldname($failed->getColumn(), BasePeer::TYPE_COLNAME, BasePeer::TYPE_PHPNAME);
            $request->setError($col, $failed->getMessage());
        }
    }

    return $res;
	}

	
	public static function retrieveByPK($pk, $con = null)
	{
		if ($con === null) {
			$con = Propel::getConnection(self::DATABASE_NAME);
		}

		$criteria = new Criteria(sediciPeer::DATABASE_NAME);

		$criteria->add(sediciPeer::ID, $pk);


		$v = sediciPeer::doSelect($criteria, $con);

		return !empty($v) > 0 ? $v[0] : null;
	}

	
	public static function retrieveByPKs($pks, $con = null)
	{
		if ($con === null) {
			$con = Propel::getConnection(self::DATABASE_NAME);
		}

		$objs = null;
		if (empty($pks)) {
			$objs = array();
		} else {
			$criteria = new Criteria();
			$criteria->add(sediciPeer::ID, $pks, Criteria::IN);
			$objs = sediciPeer::doSelect($criteria, $con);
		}
		return $objs;
	}

} 
if (Propel::isInit()) {
			try {
		BasesediciPeer::getMapBuilder();
	} catch (Exception $e) {
		Propel::log('Could not initialize Peer: ' . $e->getMessage(), Propel::LOG_ERR);
	}
} else {
			require_once 'plugins/sfDspacePlugin/lib/model/map/sediciMapBuilder.php';
	Propel::registerMapBuilder('plugins.sfDspacePlugin.lib.model.map.sediciMapBuilder');
}
