<?php


abstract class Basesubtipos extends BaseObject  implements Persistent {


	
	protected static $peer;


	
	protected $id;


	
	protected $article;


	
	protected $book;


	
	protected $preprint;


	
	protected $working_paper;


	
	protected $technical_report;


	
	protected $conference_object;


	
	protected $revision;


	
	protected $work_specialization;


	
	protected $phd;


	
	protected $licentiate;


	
	protected $master;


	
	protected $id_sedici;

	
	protected $alreadyInSave = false;

	
	protected $alreadyInValidation = false;

	
	public function getId()
	{

		return $this->id;
	}

	
	public function getArticle()
	{

		return $this->article;
	}

	
	public function getBook()
	{

		return $this->book;
	}

	
	public function getPreprint()
	{

		return $this->preprint;
	}

	
	public function getWorkingPaper()
	{

		return $this->working_paper;
	}

	
	public function getTechnicalReport()
	{

		return $this->technical_report;
	}

	
	public function getConferenceObject()
	{

		return $this->conference_object;
	}

	
	public function getRevision()
	{

		return $this->revision;
	}

	
	public function getWorkSpecialization()
	{

		return $this->work_specialization;
	}

	
	public function getPhd()
	{

		return $this->phd;
	}

	
	public function getLicentiate()
	{

		return $this->licentiate;
	}

	
	public function getMaster()
	{

		return $this->master;
	}

	
	public function getIdSedici()
	{

		return $this->id_sedici;
	}

	
	public function setId($v)
	{

						if ($v !== null && !is_int($v) && is_numeric($v)) {
			$v = (int) $v;
		}

		if ($this->id !== $v) {
			$this->id = $v;
			$this->modifiedColumns[] = subtiposPeer::ID;
		}

	} 
	
	public function setArticle($v)
	{

		if ($this->article !== $v) {
			$this->article = $v;
			$this->modifiedColumns[] = subtiposPeer::ARTICLE;
		}

	} 
	
	public function setBook($v)
	{

		if ($this->book !== $v) {
			$this->book = $v;
			$this->modifiedColumns[] = subtiposPeer::BOOK;
		}

	} 
	
	public function setPreprint($v)
	{

		if ($this->preprint !== $v) {
			$this->preprint = $v;
			$this->modifiedColumns[] = subtiposPeer::PREPRINT;
		}

	} 
	
	public function setWorkingPaper($v)
	{

		if ($this->working_paper !== $v) {
			$this->working_paper = $v;
			$this->modifiedColumns[] = subtiposPeer::WORKING_PAPER;
		}

	} 
	
	public function setTechnicalReport($v)
	{

		if ($this->technical_report !== $v) {
			$this->technical_report = $v;
			$this->modifiedColumns[] = subtiposPeer::TECHNICAL_REPORT;
		}

	} 
	
	public function setConferenceObject($v)
	{

		if ($this->conference_object !== $v) {
			$this->conference_object = $v;
			$this->modifiedColumns[] = subtiposPeer::CONFERENCE_OBJECT;
		}

	} 
	
	public function setRevision($v)
	{

		if ($this->revision !== $v) {
			$this->revision = $v;
			$this->modifiedColumns[] = subtiposPeer::REVISION;
		}

	} 
	
	public function setWorkSpecialization($v)
	{

		if ($this->work_specialization !== $v) {
			$this->work_specialization = $v;
			$this->modifiedColumns[] = subtiposPeer::WORK_SPECIALIZATION;
		}

	} 
	
	public function setPhd($v)
	{

		if ($this->phd !== $v) {
			$this->phd = $v;
			$this->modifiedColumns[] = subtiposPeer::PHD;
		}

	} 
	
	public function setLicentiate($v)
	{

		if ($this->licentiate !== $v) {
			$this->licentiate = $v;
			$this->modifiedColumns[] = subtiposPeer::LICENTIATE;
		}

	} 
	
	public function setMaster($v)
	{

		if ($this->master !== $v) {
			$this->master = $v;
			$this->modifiedColumns[] = subtiposPeer::MASTER;
		}

	} 
	
	public function setIdSedici($v)
	{

						if ($v !== null && !is_int($v) && is_numeric($v)) {
			$v = (int) $v;
		}

		if ($this->id_sedici !== $v) {
			$this->id_sedici = $v;
			$this->modifiedColumns[] = subtiposPeer::ID_SEDICI;
		}

	} 
	
	public function hydrate(ResultSet $rs, $startcol = 1)
	{
		try {

			$this->id = $rs->getInt($startcol + 0);

			$this->article = $rs->getBoolean($startcol + 1);

			$this->book = $rs->getBoolean($startcol + 2);

			$this->preprint = $rs->getBoolean($startcol + 3);

			$this->working_paper = $rs->getBoolean($startcol + 4);

			$this->technical_report = $rs->getBoolean($startcol + 5);

			$this->conference_object = $rs->getBoolean($startcol + 6);

			$this->revision = $rs->getBoolean($startcol + 7);

			$this->work_specialization = $rs->getBoolean($startcol + 8);

			$this->phd = $rs->getBoolean($startcol + 9);

			$this->licentiate = $rs->getBoolean($startcol + 10);

			$this->master = $rs->getBoolean($startcol + 11);

			$this->id_sedici = $rs->getInt($startcol + 12);

			$this->resetModified();

			$this->setNew(false);

						return $startcol + 13; 
		} catch (Exception $e) {
			throw new PropelException("Error populating subtipos object", $e);
		}
	}

	
	public function delete($con = null)
	{

    foreach (sfMixer::getCallables('Basesubtipos:delete:pre') as $callable)
    {
      $ret = call_user_func($callable, $this, $con);
      if ($ret)
      {
        return;
      }
    }


		if ($this->isDeleted()) {
			throw new PropelException("This object has already been deleted.");
		}

		if ($con === null) {
			$con = Propel::getConnection(subtiposPeer::DATABASE_NAME);
		}

		try {
			$con->begin();
			subtiposPeer::doDelete($this, $con);
			$this->setDeleted(true);
			$con->commit();
		} catch (PropelException $e) {
			$con->rollback();
			throw $e;
		}
	

    foreach (sfMixer::getCallables('Basesubtipos:delete:post') as $callable)
    {
      call_user_func($callable, $this, $con);
    }

  }
	
	public function save($con = null)
	{

    foreach (sfMixer::getCallables('Basesubtipos:save:pre') as $callable)
    {
      $affectedRows = call_user_func($callable, $this, $con);
      if (is_int($affectedRows))
      {
        return $affectedRows;
      }
    }


		if ($this->isDeleted()) {
			throw new PropelException("You cannot save an object that has been deleted.");
		}

		if ($con === null) {
			$con = Propel::getConnection(subtiposPeer::DATABASE_NAME);
		}

		try {
			$con->begin();
			$affectedRows = $this->doSave($con);
			$con->commit();
    foreach (sfMixer::getCallables('Basesubtipos:save:post') as $callable)
    {
      call_user_func($callable, $this, $con, $affectedRows);
    }

			return $affectedRows;
		} catch (PropelException $e) {
			$con->rollback();
			throw $e;
		}
	}

	
	protected function doSave($con)
	{
		$affectedRows = 0; 		if (!$this->alreadyInSave) {
			$this->alreadyInSave = true;


						if ($this->isModified()) {
				if ($this->isNew()) {
					$pk = subtiposPeer::doInsert($this, $con);
					$affectedRows += 1; 										 										 
					$this->setId($pk);  
					$this->setNew(false);
				} else {
					$affectedRows += subtiposPeer::doUpdate($this, $con);
				}
				$this->resetModified(); 			}

			$this->alreadyInSave = false;
		}
		return $affectedRows;
	} 
	
	protected $validationFailures = array();

	
	public function getValidationFailures()
	{
		return $this->validationFailures;
	}

	
	public function validate($columns = null)
	{
		$res = $this->doValidate($columns);
		if ($res === true) {
			$this->validationFailures = array();
			return true;
		} else {
			$this->validationFailures = $res;
			return false;
		}
	}

	
	protected function doValidate($columns = null)
	{
		if (!$this->alreadyInValidation) {
			$this->alreadyInValidation = true;
			$retval = null;

			$failureMap = array();


			if (($retval = subtiposPeer::doValidate($this, $columns)) !== true) {
				$failureMap = array_merge($failureMap, $retval);
			}



			$this->alreadyInValidation = false;
		}

		return (!empty($failureMap) ? $failureMap : true);
	}

	
	public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
	{
		$pos = subtiposPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
		return $this->getByPosition($pos);
	}

	
	public function getByPosition($pos)
	{
		switch($pos) {
			case 0:
				return $this->getId();
				break;
			case 1:
				return $this->getArticle();
				break;
			case 2:
				return $this->getBook();
				break;
			case 3:
				return $this->getPreprint();
				break;
			case 4:
				return $this->getWorkingPaper();
				break;
			case 5:
				return $this->getTechnicalReport();
				break;
			case 6:
				return $this->getConferenceObject();
				break;
			case 7:
				return $this->getRevision();
				break;
			case 8:
				return $this->getWorkSpecialization();
				break;
			case 9:
				return $this->getPhd();
				break;
			case 10:
				return $this->getLicentiate();
				break;
			case 11:
				return $this->getMaster();
				break;
			case 12:
				return $this->getIdSedici();
				break;
			default:
				return null;
				break;
		} 	}

	
	public function toArray($keyType = BasePeer::TYPE_PHPNAME)
	{
		$keys = subtiposPeer::getFieldNames($keyType);
		$result = array(
			$keys[0] => $this->getId(),
			$keys[1] => $this->getArticle(),
			$keys[2] => $this->getBook(),
			$keys[3] => $this->getPreprint(),
			$keys[4] => $this->getWorkingPaper(),
			$keys[5] => $this->getTechnicalReport(),
			$keys[6] => $this->getConferenceObject(),
			$keys[7] => $this->getRevision(),
			$keys[8] => $this->getWorkSpecialization(),
			$keys[9] => $this->getPhd(),
			$keys[10] => $this->getLicentiate(),
			$keys[11] => $this->getMaster(),
			$keys[12] => $this->getIdSedici(),
		);
		return $result;
	}

	
	public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
	{
		$pos = subtiposPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
		return $this->setByPosition($pos, $value);
	}

	
	public function setByPosition($pos, $value)
	{
		switch($pos) {
			case 0:
				$this->setId($value);
				break;
			case 1:
				$this->setArticle($value);
				break;
			case 2:
				$this->setBook($value);
				break;
			case 3:
				$this->setPreprint($value);
				break;
			case 4:
				$this->setWorkingPaper($value);
				break;
			case 5:
				$this->setTechnicalReport($value);
				break;
			case 6:
				$this->setConferenceObject($value);
				break;
			case 7:
				$this->setRevision($value);
				break;
			case 8:
				$this->setWorkSpecialization($value);
				break;
			case 9:
				$this->setPhd($value);
				break;
			case 10:
				$this->setLicentiate($value);
				break;
			case 11:
				$this->setMaster($value);
				break;
			case 12:
				$this->setIdSedici($value);
				break;
		} 	}

	
	public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
	{
		$keys = subtiposPeer::getFieldNames($keyType);

		if (array_key_exists($keys[0], $arr)) $this->setId($arr[$keys[0]]);
		if (array_key_exists($keys[1], $arr)) $this->setArticle($arr[$keys[1]]);
		if (array_key_exists($keys[2], $arr)) $this->setBook($arr[$keys[2]]);
		if (array_key_exists($keys[3], $arr)) $this->setPreprint($arr[$keys[3]]);
		if (array_key_exists($keys[4], $arr)) $this->setWorkingPaper($arr[$keys[4]]);
		if (array_key_exists($keys[5], $arr)) $this->setTechnicalReport($arr[$keys[5]]);
		if (array_key_exists($keys[6], $arr)) $this->setConferenceObject($arr[$keys[6]]);
		if (array_key_exists($keys[7], $arr)) $this->setRevision($arr[$keys[7]]);
		if (array_key_exists($keys[8], $arr)) $this->setWorkSpecialization($arr[$keys[8]]);
		if (array_key_exists($keys[9], $arr)) $this->setPhd($arr[$keys[9]]);
		if (array_key_exists($keys[10], $arr)) $this->setLicentiate($arr[$keys[10]]);
		if (array_key_exists($keys[11], $arr)) $this->setMaster($arr[$keys[11]]);
		if (array_key_exists($keys[12], $arr)) $this->setIdSedici($arr[$keys[12]]);
	}

	
	public function buildCriteria()
	{
		$criteria = new Criteria(subtiposPeer::DATABASE_NAME);

		if ($this->isColumnModified(subtiposPeer::ID)) $criteria->add(subtiposPeer::ID, $this->id);
		if ($this->isColumnModified(subtiposPeer::ARTICLE)) $criteria->add(subtiposPeer::ARTICLE, $this->article);
		if ($this->isColumnModified(subtiposPeer::BOOK)) $criteria->add(subtiposPeer::BOOK, $this->book);
		if ($this->isColumnModified(subtiposPeer::PREPRINT)) $criteria->add(subtiposPeer::PREPRINT, $this->preprint);
		if ($this->isColumnModified(subtiposPeer::WORKING_PAPER)) $criteria->add(subtiposPeer::WORKING_PAPER, $this->working_paper);
		if ($this->isColumnModified(subtiposPeer::TECHNICAL_REPORT)) $criteria->add(subtiposPeer::TECHNICAL_REPORT, $this->technical_report);
		if ($this->isColumnModified(subtiposPeer::CONFERENCE_OBJECT)) $criteria->add(subtiposPeer::CONFERENCE_OBJECT, $this->conference_object);
		if ($this->isColumnModified(subtiposPeer::REVISION)) $criteria->add(subtiposPeer::REVISION, $this->revision);
		if ($this->isColumnModified(subtiposPeer::WORK_SPECIALIZATION)) $criteria->add(subtiposPeer::WORK_SPECIALIZATION, $this->work_specialization);
		if ($this->isColumnModified(subtiposPeer::PHD)) $criteria->add(subtiposPeer::PHD, $this->phd);
		if ($this->isColumnModified(subtiposPeer::LICENTIATE)) $criteria->add(subtiposPeer::LICENTIATE, $this->licentiate);
		if ($this->isColumnModified(subtiposPeer::MASTER)) $criteria->add(subtiposPeer::MASTER, $this->master);
		if ($this->isColumnModified(subtiposPeer::ID_SEDICI)) $criteria->add(subtiposPeer::ID_SEDICI, $this->id_sedici);

		return $criteria;
	}

	
	public function buildPkeyCriteria()
	{
		$criteria = new Criteria(subtiposPeer::DATABASE_NAME);

		$criteria->add(subtiposPeer::ID, $this->id);

		return $criteria;
	}

	
	public function getPrimaryKey()
	{
		return $this->getId();
	}

	
	public function setPrimaryKey($key)
	{
		$this->setId($key);
	}

	
	public function copyInto($copyObj, $deepCopy = false)
	{

		$copyObj->setArticle($this->article);

		$copyObj->setBook($this->book);

		$copyObj->setPreprint($this->preprint);

		$copyObj->setWorkingPaper($this->working_paper);

		$copyObj->setTechnicalReport($this->technical_report);

		$copyObj->setConferenceObject($this->conference_object);

		$copyObj->setRevision($this->revision);

		$copyObj->setWorkSpecialization($this->work_specialization);

		$copyObj->setPhd($this->phd);

		$copyObj->setLicentiate($this->licentiate);

		$copyObj->setMaster($this->master);

		$copyObj->setIdSedici($this->id_sedici);


		$copyObj->setNew(true);

		$copyObj->setId(NULL); 
	}

	
	public function copy($deepCopy = false)
	{
				$clazz = get_class($this);
		$copyObj = new $clazz();
		$this->copyInto($copyObj, $deepCopy);
		return $copyObj;
	}

	
	public function getPeer()
	{
		if (self::$peer === null) {
			self::$peer = new subtiposPeer();
		}
		return self::$peer;
	}


  public function __call($method, $arguments)
  {
    if (!$callable = sfMixer::getCallable('Basesubtipos:'.$method))
    {
      throw new sfException(sprintf('Call to undefined method Basesubtipos::%s', $method));
    }

    array_unshift($arguments, $this);

    return call_user_func_array($callable, $arguments);
  }


} 