<?php

/**
 * Subclass for representing a row from the 'ds_sedici' table.
 *
 * 
 *
 * @package plugins.sfDspacePlugin.lib.model
 */ 
class sedici extends Basesedici
{
}
