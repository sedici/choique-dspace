<?php

/**
 * Subclass for performing query and update operations on the 'ds_sedici' table.
 *
 * 
 *
 * @package plugins.sfDspacePlugin.lib.model
 */ 
class sediciPeer extends BasesediciPeer
{
}
