<?php

/**
 * Subclass for representing a row from the 'ds_subtipos' table.
 *
 * 
 *
 * @package plugins.sfDspacePlugin.lib.model
 */ 
class subtipos extends Basesubtipos
{
}
