<?php

/**
 * Subclass for performing query and update operations on the 'ds_subtipos' table.
 *
 * 
 *
 * @package plugins.sfDspacePlugin.lib.model
 */ 
class subtiposPeer extends BasesubtiposPeer
{
}
